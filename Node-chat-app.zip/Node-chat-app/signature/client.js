const crypto = require("crypto");
const io = require("socket.io-client");
const readline = require("readline");

const socket = io("http://localhost:3000");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let registeredUsername = "";
let username = "";
let privateKey, publicKey; // Private and public keys for RSA
const users = new Map();

// Function to sign a message
function signMessage(message) {
  const sign = crypto.createSign("sha256");
  sign.update(message);
  sign.end();
  return sign.sign(privateKey, "hex");
}

// Function to verify a signed message
function verifySignature(message, signature, user) {
  const verify = crypto.createVerify("sha256");
  verify.update(message);
  verify.end();
  const publicKey = users.get(user);
  return verify.verify(publicKey, signature, "hex");
}

socket.on("connect", () => {
  console.log("Connected to the server");

  rl.question("Enter your username: ", (input) => {
    username = input;
    registeredUsername = input;
    console.log(`Welcome, ${username} to the chat`);

    // Generate keys (for simplicity, generating them here)
    const { privateKey: privKey, publicKey: pubKey } = crypto.generateKeyPairSync("rsa", {
      modulusLength: 2048,
    });
    privateKey = privKey;
    publicKey = pubKey.export({ type: "pkcs1", format: "pem" });

    // Register public key with server
    socket.emit("registerPublicKey", {
      username,
      publicKey: publicKey.toString("pem"),
    });

    rl.prompt();

    rl.on("line", (message) => {
      if (message.trim()) {
        if ((match = message.match(/^!impersonate (\w+)$/))) {
          username = match[1];
          console.log(`Now impersonating as ${username}`);
        } else if (message.match(/^!exit$/)) {
          username = registeredUsername;
          console.log(`Now you are ${username}`);
        } else {
          // Sign the message before sending
          const signature = signMessage(message);
          socket.emit("message", { username, message, signature });
        }
      }
      rl.prompt();
    });
  });
});

socket.on("init", (keys) => {
  keys.forEach(([user, key]) => users.set(user, key));
  console.log(`\nThere are currently ${users.size} users in the chat`);
  rl.prompt();
});

socket.on("newUser", (data) => {
  const { username, publicKey } = data;
  users.set(username, publicKey);
  console.log(`${username} joined the chat`);
  rl.prompt();
});

socket.on("message", (data) => {
  const { username: senderUsername, message: senderMessage, signature } = data;
  if (senderUsername !== username) {
    // Verify the sender's signature
    if (verifySignature(senderMessage, signature, senderUsername)) {
      console.log(`${senderUsername}: ${senderMessage}`);
    } else {
      console.log(`(${senderMessage}) Warning ${senderUsername} is a fake user!`);
    }
    rl.prompt();
  }
});

socket.on("disconnect", () => {
  console.log("Server disconnected, Exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});
